<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Auth
{

    public function xmlhttprequest() {
    	echo "success";
    }
}