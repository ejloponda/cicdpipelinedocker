<link rel="stylesheet" href="<?php echo BASE_FOLDER ?>themes/css/style.css" />
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
<body>
	<div class="img-holder">
		<img class="maintenance" src="<?php echo BASE_FOLDER ?>themes/images/404bruce.jpg">
	</div>
	<p class="text">THIS WEBSITE IS POWERED BY <a href="http://www.razerbite.com/">RAZERBITE SOLUTIONS</a></p>
</body>