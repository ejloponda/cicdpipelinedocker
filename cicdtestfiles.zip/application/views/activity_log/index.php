<?php include('themes/templates/includes/user-header.php'); ?>
<?php include('themes/templates/includes/user-sidebar.php'); ?>
<script>
	$(function() {
		reload_content();
	});
</script>
<div id="main_wrapper_management"> </div>
<?php include('themes/templates/footer/user-footer.php'); ?>

