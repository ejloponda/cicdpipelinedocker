<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// REQUIRED VARIABLES

/* LIVE SERVER */
/*$config['pusher_api_key'] = 'e3c363e14534352d529b';
$config['pusher_secret'] = '624f139c6e81541e251d';
$config['pusher_app_id'] = '87334';*/

/* SANDBOX */
$config['pusher_api_key'] = '45aa8c5ecca116b2a369';
$config['pusher_secret'] = '35a18121ff79d5d10765';
$config['pusher_app_id'] = '87339';

// OPTIONAL VARIABLES
// $config['pusher_host'] = ''; // Default is: http://api.pusherapp.com
// $config['pusher_port'] = ''; // Default is: 80
// $config['pusher_url'] = '';  // Default is: /apps/$config['pusher_app_id']
// $config['pusher_debug'] = ''; // Default is: FALSE
// $config['pusher_timeout'] = ''; // Default is: 30

/* End of file pusher.php */
/* Location: ./application/config/pusher.php */